<?php
/**
 * The home page file.
 *
 * @package understrap
 */

get_header();

$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="home-wrapper">
  <div class="home-jumbotron">
    <div class="home-jumbotron-text">
      <h1>Innovation through engineering.</h1>
      <i class="fas fa-angle-down home-arrow"></i>
    </div>
    <div class="clouds">
      <img src="https://i.ibb.co/nBQYWTJ/cloud1.png" alt="cloud1" style="--i:1;" />
      <img src="https://i.ibb.co/0J1nPdK/cloud2.png" alt="cloud2" style="--i:2;" />
      <img src="https://i.ibb.co/1nKdFKR/cloud3.png" alt="cloud3" style="--i:3;" />
      <img src="https://i.ibb.co/zQWDfQx/cloud4.png" alt="cloud4" style="--i:4;" />
      <img src="https://i.ibb.co/WfSkWb4/cloud5.png" alt="cloud5" style="--i:5;" />
      <img src="https://i.ibb.co/nBQYWTJ/cloud1.png" alt="cloud1" style="--i:10;" />
      <img src="https://i.ibb.co/0J1nPdK/cloud2.png" alt="cloud2" style="--i:9;" />
      <img src="https://i.ibb.co/1nKdFKR/cloud3.png" alt="cloud3" style="--i:8;" />
      <img src="https://i.ibb.co/zQWDfQx/cloud4.png" alt="cloud4" style="--i:7;" />
      <img src="https://i.ibb.co/WfSkWb4/cloud5.png" alt="cloud5" style="--i:6;" />
    </div>
  </div>
  <div class="wrapper" id="index-wrapper">
    <div class="content" tabindex="-1">
      <div class="row">
        <div class="col-sm-12">
          <h6 class="home-feature-text">At <span class="home-feature-accent-text">Hinetics</span> we believe the future
            lies in <span class="home-feature-accent-text">clean renewable energy</span> and <span
              class="home-feature-accent-text">electrified transportation</span>
            to reduce
            global dependence on fossil fuels. As such, we <span class="home-feature-accent-text">push the limits</span>
            of electric machine performance to enable <span class="home-feature-accent-text">new
              applications</span>, achieve <span class="home-feature-accent-text">higher efficiency</span>, and lead to
            more <span class="home-feature-accent-text">cost effective</span> clean energy solutions. We target high
            impact application areas such as <span class="home-feature-accent-text">large off-shore wind energy</span>
            generation and <span class="home-feature-accent-text">electric air transportation</span> to
            demonstrate the impact of our technology on a sustainable future.</h6>
        </div>
      </div>
    </div><!-- #content -->
  </div><!-- #index-wrapper -->
  <div class="wrapper" id="index-wrapper">
    <div class="content" tabindex="-1">
      <div class="row">
        <div class="col-sm-12">
          <h2>Our Partners</h2>
        </div>
      </div>
      <div class="row home-partners">
        <img src="https://i.ibb.co/k9LVkJC/Altair-Logo.png" alt="Altair-Logo" border="0">
        <img src="https://i.ibb.co/V278hv9/Autodesk-Logo.png" alt="Autodesk-Logo" border="0">
        <img src="https://i.ibb.co/BN1Zy30/Illinois-Logo.png" alt="Illinois-Logo" border="0">
        <img src="https://i.ibb.co/ctnmgyC/NASA-Logo.png" alt="NASA-Logo" border="0">
        <img src="https://i.ibb.co/MSC2Hcx/NSF-Logo.png" alt="NSF-Logo" border="0">
      </div>
    </div><!-- #content -->
  </div><!-- #index-wrapper -->

  <?php get_footer(); ?>
</div>